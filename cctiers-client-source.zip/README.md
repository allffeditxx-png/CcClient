# CcTiers Client

Fabric client mod for Minecraft 1.21.11 by AyushXDP. Remove the standalone CCTiers mod - the tier tagger is built in.

- **Right Shift** (or `/ccclient`) opens the card menu. Left-click a card to enable/disable it; right-click (or Edit) opens its settings.
- **UI theme**: Black & Gold (default) or Normal - button in the menu header and on the main screen.
- **Main screen**: your photo as a slowly moving background, your tiers on top (click for your profile), buttons for Singleplayer, Multiplayer, Options, Accounts, Quit, plus every button other mods add (Mod Menu, Replay Mod, Flashback...).
- **CcTiers Tag** (tier tagger): logo + gamemode icon + tier on nametags, tab list and chat. Same API as CCTiers. `/cctiers <player>` opens a profile, `/cctiers refresh|register|toggle`.
- **Accounts**: switch between saved offline accounts in game, or go back to the launcher account.
- HUD cards: FPS, Coordinates, Biome, Direction, Clock, Memory, TPS, Ping, Day, Speed, CPS, Combo, Reach, Keystrokes, Motion Blur.
- Config: `config/ccclient.json`.
