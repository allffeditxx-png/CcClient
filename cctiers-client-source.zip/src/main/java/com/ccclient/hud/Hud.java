package com.ccclient.hud;

import com.ccclient.core.Cfg;
import com.ccclient.core.Mod;
import com.ccclient.core.Palette;
import com.ccclient.core.Stats;
import com.ccclient.core.TpsTracker;
import com.ccclient.ui.Gfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Draws every enabled HUD card. Each card's box is remembered so the layout editor can move it. */
public final class Hud {
    private Hud() {}

    /** true while the layout editor is open. */
    public static boolean preview = false;
    public static final Map<String, int[]> bounds = new HashMap<>();

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();

        for (Mod m : Mod.ALL) {
            if (!m.positioned || !Cfg.on(m.id)) {
                bounds.remove(m.id);
                continue;
            }
            int[] b;
            if (m.id.equals("keystrokes")) {
                b = keystrokes(ctx, mc, tr, m, sw, sh);
            } else {
                String text = text(mc, mc.player, m);
                if (text == null) {
                    if (!preview) {
                        bounds.remove(m.id);
                        continue;
                    }
                    text = m.name;
                }
                b = panel(ctx, tr, m, text, sw, sh);
            }
            bounds.put(m.id, b);
        }
    }

    // ------------------------------------------------------------------ helpers

    private static int bg(Mod m) {
        return Palette.withAlpha(Palette.bgRgb(Cfg.val(m.id, "bgColor")), Cfg.val(m.id, "bgAlpha") * 255 / 100);
    }

    private static int[] place(Mod m, int w, int h, int sw, int sh) {
        int x = Math.round(Cfg.posX(m) * sw);
        int y = Math.round(Cfg.posY(m) * sh);
        x = Math.max(0, Math.min(sw - w, x));
        y = Math.max(0, Math.min(sh - h, y));
        return new int[]{x, y, w, h};
    }

    private static int[] panel(DrawContext ctx, TextRenderer tr, Mod m, String text, int sw, int sh) {
        int w = tr.getWidth(text) + 8;
        int h = 14;
        int[] b = place(m, w, h, sw, sh);
        if (Cfg.flag(m.id, "bg")) Gfx.round(ctx, b[0], b[1], w, h, bg(m));
        ctx.drawTextWithShadow(tr, text, b[0] + 4, b[1] + 3, Palette.argb(Cfg.val(m.id, "color")));
        return b;
    }

    private static String pretty(String path) {
        StringBuilder sb = new StringBuilder();
        for (String w : path.split("_")) {
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ text of each card

    private static String text(MinecraftClient mc, ClientPlayerEntity p, Mod m) {
        switch (m.id) {
            case "fps":
                return "FPS: " + mc.getCurrentFps();
            case "coords": {
                int d = Cfg.val("coords", "decimals");
                if (d == 0) return "XYZ: " + p.getBlockPos().getX() + " " + p.getBlockPos().getY() + " " + p.getBlockPos().getZ();
                String f = "%." + d + "f";
                return String.format(Locale.ROOT, "XYZ: " + f + " " + f + " " + f, p.getX(), p.getY(), p.getZ());
            }
            case "biome": {
                String biome = mc.world.getBiome(p.getBlockPos()).getKey().map(k -> k.getValue().getPath()).orElse("unknown");
                return "Biome: " + pretty(biome);
            }
            case "direction": {
                String face = pretty(p.getHorizontalFacing().asString());
                if (!Cfg.flag("direction", "degrees")) return "Facing: " + face;
                float yaw = ((p.getYaw() % 360f) + 360f) % 360f;
                return "Facing: " + face + " (" + Math.round(yaw) + ")";
            }
            case "clock": {
                boolean h12 = Cfg.val("clock", "fmt") == 1;
                boolean sec = Cfg.flag("clock", "seconds");
                String pattern = (h12 ? "hh:mm" : "HH:mm") + (sec ? ":ss" : "") + (h12 ? " a" : "");
                return "Time: " + LocalTime.now().format(DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH));
            }
            case "memory": {
                Runtime rt = Runtime.getRuntime();
                long max = rt.maxMemory() / 1048576L;
                long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
                if (Cfg.val("memory", "mode") == 1) return "Mem: " + (used * 100 / Math.max(1, max)) + "%";
                return "Mem: " + used + "/" + max + " MB";
            }
            case "tps": {
                Double t = TpsTracker.tps();
                return t == null ? "TPS: -" : String.format(Locale.ROOT, "TPS: %.1f", t);
            }
            case "ping": {
                int ping = 0;
                if (mc.getNetworkHandler() != null) {
                    PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
                    if (e != null) ping = e.getLatency();
                }
                return "Ping: " + ping + " ms";
            }
            case "day":
                return "Day: " + (mc.world.getTime() / 24000L + 1);
            case "speed": {
                double s = Cfg.flag("speed", "vertical") ? Stats.speed3 : Stats.speedH;
                if (Cfg.val("speed", "unit") == 1) return String.format(Locale.ROOT, "Speed: %.1f km/h", s * 3.6);
                return String.format(Locale.ROOT, "Speed: %.1f b/s", s);
            }
            case "cps": {
                int mode = Cfg.val("cps", "mode");
                if (mode == 1) return "CPS: " + Stats.leftCps();
                if (mode == 2) return "CPS: " + Stats.rightCps();
                return "CPS: " + Stats.leftCps() + " | " + Stats.rightCps();
            }
            case "combo":
                return "Combo: " + Stats.combo;
            case "reach": {
                String f = "%." + Cfg.val("reach", "decimals") + "f";
                return "Reach: " + (Stats.hasReach ? String.format(Locale.ROOT, f, Stats.reach) : "-");
            }
            default:
                return null;
        }
    }

    // ------------------------------------------------------------------ keystrokes

    private static boolean mouseDown(MinecraftClient mc, int button) {
        return mc.currentScreen == null && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), button) == GLFW.GLFW_PRESS;
    }

    private static int[] keystrokes(DrawContext ctx, MinecraftClient mc, TextRenderer tr, Mod m, int sw, int sh) {
        boolean mouse = Cfg.flag(m.id, "mouse"), space = Cfg.flag(m.id, "space"), shift = Cfg.flag(m.id, "shift");
        int k = 20, g = 2;
        int w = k * 3 + g * 2;
        int h = k * 2 + g;
        if (space) h += g + 14;
        if (shift) h += g + 14;
        if (mouse) h += g + 22;
        int[] b = place(m, w, h, sw, sh);
        int x = b[0], y = b[1];
        int bgc = Cfg.flag(m.id, "bg") ? bg(m) : 0;
        int col = Palette.argb(Cfg.val(m.id, "color"));

        key(ctx, tr, "W", x + k + g, y, k, k, mc.options.forwardKey.isPressed(), col, bgc);
        key(ctx, tr, "A", x, y + k + g, k, k, mc.options.leftKey.isPressed(), col, bgc);
        key(ctx, tr, "S", x + k + g, y + k + g, k, k, mc.options.backKey.isPressed(), col, bgc);
        key(ctx, tr, "D", x + (k + g) * 2, y + k + g, k, k, mc.options.rightKey.isPressed(), col, bgc);
        int cy = y + k * 2 + g * 2;
        if (space) {
            key(ctx, tr, "SPACE", x, cy, w, 14, mc.options.jumpKey.isPressed(), col, bgc);
            cy += 14 + g;
        }
        if (shift) {
            key(ctx, tr, "SHIFT", x, cy, w, 14, mc.options.sneakKey.isPressed(), col, bgc);
            cy += 14 + g;
        }
        if (mouse) {
            int bw = (w - g) / 2;
            key(ctx, tr, "LMB", x, cy, bw, 22, mouseDown(mc, GLFW.GLFW_MOUSE_BUTTON_LEFT), col, bgc);
            key(ctx, tr, "RMB", x + bw + g, cy, bw, 22, mouseDown(mc, GLFW.GLFW_MOUSE_BUTTON_RIGHT), col, bgc);
            String l = String.valueOf(Stats.leftCps()), r = String.valueOf(Stats.rightCps());
            ctx.drawText(tr, l, x + (bw - tr.getWidth(l)) / 2, cy + 12, 0xFFAAAAAA, false);
            ctx.drawText(tr, r, x + bw + g + (bw - tr.getWidth(r)) / 2, cy + 12, 0xFFAAAAAA, false);
        }
        return b;
    }

    private static void key(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w, int h, boolean down, int col, int bgc) {
        if (down || (bgc >>> 24) != 0) Gfx.round(ctx, x, y, w, h, down ? Palette.withAlpha(col, 230) : bgc);
        int ty = h >= 22 ? y + 3 : y + (h - 8) / 2 + 1;
        ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, ty, down ? 0xFF000000 : col, false);
    }
}
