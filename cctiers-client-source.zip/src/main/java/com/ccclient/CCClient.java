package com.ccclient;

import com.ccclient.blur.MotionBlur;
import com.ccclient.core.Accounts;
import com.ccclient.core.Cfg;
import com.ccclient.core.Mods;
import com.ccclient.core.Stats;
import com.ccclient.data.TierApi;
import com.ccclient.data.TierCfg;
import com.ccclient.hud.Hud;
import com.ccclient.ui.CCCommands;
import com.ccclient.ui.CCTitleScreen;
import com.ccclient.ui.MenuScreen;
import com.ccclient.ui.Pad;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.function.Supplier;

public class CCClient implements ClientModInitializer {
    public static final String ID = "ccclient";

    /** Screens opened from a command have to wait a tick, otherwise the closing chat screen replaces them. */
    private static volatile Supplier<Screen> pendingScreen = null;
    private static volatile boolean registering = false;
    private static volatile long nextRegisterAt = 0L;
    private static int registerAttempts = 0;

    private boolean shiftPrev = false;
    private int syncTick = 0;
    private int tierTick = 0;

    @Override
    public void onInitializeClient() {
        Mods.init();
        Cfg.ensureLoaded();

        // HUD cards, drawn after the vanilla HUD
        HudElementRegistry.addLast(Identifier.of(ID, "hud"), (ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            Stats.pollClicks(mc);
            Hud.render(ctx);
        });

        // swings at entities (reach, combo)
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (world.isClient() && player == mc.player) Stats.onAttack(mc, entity, hitResult);
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Cfg.save());
        ClientCommandRegistrationCallback.EVENT.register(CCCommands::register);

        TierApi.ensureLoaded();
    }

    public static void openNextTick(Supplier<Screen> screen) {
        pendingScreen = screen;
    }

    /** POST /players for the local player (first launch, and /cctiers register). */
    public static void registerNow(MinecraftClient client) {
        if (client.player == null || registering) return;
        registering = true;
        registerAttempts++;
        String name = client.player.getName().getString();
        String uuid = client.player.getUuid().toString();
        TierApi.register(name, uuid, ok -> {
            if (ok) {
                TierCfg.markRegistered();
            } else {
                nextRegisterAt = System.currentTimeMillis() + 60_000L;
            }
            registering = false;
        });
    }

    private void tick(MinecraftClient mc) {
        if (mc.getWindow() == null) return;
        Accounts.captureOriginal(mc);

        // screens requested by commands
        Supplier<Screen> pending = pendingScreen;
        if (pending != null) {
            pendingScreen = null;
            mc.setScreen(pending.get());
        }

        // our main screen instead of the vanilla one
        if (mc.currentScreen instanceof TitleScreen && mc.world == null) {
            mc.setScreen(new CCTitleScreen());
            return;
        }

        // Right Shift opens the card menu (only when no other screen is open)
        boolean shift = Pad.key(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
        if (shift && !shiftPrev && mc.currentScreen == null && mc.player != null) {
            mc.setScreen(new MenuScreen(null));
        }
        shiftPrev = shift;

        // tier tagger: register the local player once, keep the list fresh
        if (mc.player != null && Cfg.on("cctiers_tag")) {
            TierCfg c = TierCfg.get();
            if (c.registerPlayer && !c.registered && registerAttempts < 3 && !registering && System.currentTimeMillis() >= nextRegisterAt) {
                registerNow(mc);
            }
            if (++tierTick % 100 == 0) TierApi.ensureLoaded();
        }

        Stats.tick(mc);
        MotionBlur.tick(mc);
        if (++syncTick >= 20) {
            syncTick = 0;
            if (!(mc.currentScreen instanceof MenuScreen)) MotionBlur.sync(mc);
        }
    }
}
