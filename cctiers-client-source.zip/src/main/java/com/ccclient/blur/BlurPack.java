package com.ccclient.blur;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/** Writes the locked resource pack that does the motion blur (a post effect + two tiny shaders). */
public final class BlurPack {
    private BlurPack() {}

    public static final String NS = "ccclient";
    public static final String PACK_ID = "ccclient_blur_pack";

    private static final String MCMETA = """
            {
              "pack": {
                "description": "CcTiers Client motion blur (locked - managed by the mod)",
                "pack_format": 75,
                "min_format": 75,
                "max_format": 75
              }
            }
            """;

    private static final String BLEND_FSH = """
            #version 330

            uniform sampler2D InSampler;
            uniform sampler2D PrevSampler;

            layout(std140) uniform MotionBlurConfig {
                float Blend;
            };

            in vec2 texCoord;
            out vec4 fragColor;

            void main() {
                vec3 cur = texture(InSampler, texCoord).rgb;
                vec3 prev = texture(PrevSampler, texCoord).rgb;
                fragColor = vec4(mix(cur, prev, Blend), 1.0);
            }
            """;

    private static final String COPY_FSH = """
            #version 330

            uniform sampler2D InSampler;

            in vec2 texCoord;
            out vec4 fragColor;

            void main() {
                fragColor = vec4(texture(InSampler, texCoord).rgb, 1.0);
            }
            """;

    private static final String EFFECT = """
            {
              "targets": {
                "swap": {},
                "history": { "persistent": true }
              },
              "passes": [
                {
                  "vertex_shader": "minecraft:core/screenquad",
                  "fragment_shader": "ccclient:post/motion_blur",
                  "inputs": [
                    { "sampler_name": "In", "target": "minecraft:main" },
                    { "sampler_name": "Prev", "target": "history" }
                  ],
                  "output": "swap",
                  "uniforms": {
                    "MotionBlurConfig": [
                      { "name": "Blend", "type": "float", "value": @BLEND@ }
                    ]
                  }
                },
                {
                  "vertex_shader": "minecraft:core/screenquad",
                  "fragment_shader": "ccclient:post/copy",
                  "inputs": [
                    { "sampler_name": "In", "target": "swap" }
                  ],
                  "output": "history"
                },
                {
                  "vertex_shader": "minecraft:core/screenquad",
                  "fragment_shader": "ccclient:post/copy",
                  "inputs": [
                    { "sampler_name": "In", "target": "swap" }
                  ],
                  "output": "minecraft:main"
                }
              ]
            }
            """;

    public static Path packDir() {
        return FabricLoader.getInstance().getConfigDir().resolve("ccclient").resolve("blur_pack");
    }

    /** Writes every file that is missing or different. Returns true if anything changed. */
    public static boolean install(float blend) {
        Path root = packDir();
        try {
            boolean changed = false;
            changed |= write(root, "pack.mcmeta", MCMETA);
            String effect = EFFECT.replace("@BLEND@", String.format(Locale.ROOT, "%.4f", blend));
            changed |= write(root, "assets/" + NS + "/post_effect/motion_blur.json", effect);
            changed |= write(root, "assets/" + NS + "/shaders/post/motion_blur.fsh", BLEND_FSH);
            changed |= write(root, "assets/" + NS + "/shaders/post/copy.fsh", COPY_FSH);
            return changed;
        } catch (IOException e) {
            return false;
        }
    }

    private static boolean write(Path root, String rel, String content) throws IOException {
        Path f = root.resolve(rel);
        Files.createDirectories(f.getParent());
        if (Files.exists(f) && Files.readString(f).equals(content)) return false;
        Files.writeString(f, content);
        return true;
    }
}
