package com.ccclient.blur;

import com.ccclient.core.Cfg;
import com.ccclient.mixin.GameRendererInvoker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.Identifier;

/** Turns the blur post effect on/off and keeps the pack in sync with the card's settings. */
public final class MotionBlur {
    private MotionBlur() {}

    public static final Identifier EFFECT_ID = Identifier.of(BlurPack.NS, "motion_blur");

    private static int attempts = 0;
    private static boolean dirty = false;

    /** Same curve as the standalone Motion Blur mod: strength % raised to 60/fps, never above 0.97. */
    public static float blend() {
        int st = Math.min(Math.max(Cfg.val("motion_blur", "strength"), 0), 95);
        double s = st / 100.0;
        if (s <= 0) return 0f;
        int fps = Math.max(Cfg.val("motion_blur", "fps"), 30);
        double k = Math.pow(s, 60.0 / fps);
        return (float) Math.min(k, 0.97);
    }

    /** Every client tick. */
    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.gameRenderer == null) return;
        GameRenderer gr = mc.gameRenderer;
        boolean on = Cfg.on("motion_blur");
        Identifier cur = gr.getPostProcessorId();
        if (on) {
            if (!EFFECT_ID.equals(cur)) {
                if (attempts < 5) {
                    attempts++;
                    ((GameRendererInvoker) (Object) gr).ccclient$setPostProcessor(EFFECT_ID);
                }
            } else {
                attempts = 0;
            }
        } else if (EFFECT_ID.equals(cur)) {
            gr.clearPostProcessor();
            attempts = 0;
        }
    }

    /** Writes the pack if the strength changed and reloads resources once so the new value is used. */
    public static void sync(MinecraftClient mc) {
        if (BlurPack.install(blend())) dirty = true;
        if (dirty && Cfg.on("motion_blur") && mc.world != null) {
            dirty = false;
            attempts = 0;
            mc.reloadResources();
        }
    }
}
