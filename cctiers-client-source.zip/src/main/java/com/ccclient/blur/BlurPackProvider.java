package com.ccclient.blur;

import com.ccclient.core.Cfg;
import net.minecraft.resource.DirectoryResourcePack;
import net.minecraft.resource.ResourcePackInfo;
import net.minecraft.resource.ResourcePackPosition;
import net.minecraft.resource.ResourcePackProfile;
import net.minecraft.resource.ResourcePackProvider;
import net.minecraft.resource.ResourcePackSource;
import net.minecraft.resource.ResourceType;
import net.minecraft.text.Text;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.function.Consumer;

/** Hands the locked blur pack to the resource pack manager. */
public class BlurPackProvider implements ResourcePackProvider {

    @Override
    public void register(Consumer<ResourcePackProfile> profileAdder) {
        Cfg.ensureLoaded();
        BlurPack.install(MotionBlur.blend());
        Path dir = BlurPack.packDir();
        if (!Files.isDirectory(dir)) return;

        ResourcePackInfo info = new ResourcePackInfo(BlurPack.PACK_ID, Text.literal("CcTiers Client Motion Blur"),
                ResourcePackSource.NONE, Optional.empty());
        ResourcePackProfile profile = ResourcePackProfile.create(info,
                new DirectoryResourcePack.DirectoryBackedFactory(dir),
                ResourceType.CLIENT_RESOURCES,
                new ResourcePackPosition(true, ResourcePackProfile.InsertionPosition.TOP, true));
        if (profile != null) profileAdder.accept(profile);
    }
}
