package com.ccclient.mixin;

import com.ccclient.core.EntityLimiter;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Entities the limiter hides say "don't render me" - this is checked for every entity every frame, so it stays tiny. */
@Mixin(Entity.class)
public abstract class EntityCullMixin {

    @Inject(method = "shouldRender(DDD)Z", at = @At("HEAD"), cancellable = true, require = 0)
    private void ccclient$limit(double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        if (EntityLimiter.isHidden(((Entity) (Object) this).getId())) cir.setReturnValue(false);
    }
}
