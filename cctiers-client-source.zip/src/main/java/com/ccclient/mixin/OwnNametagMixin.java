package com.ccclient.mixin;

import com.ccclient.core.Cfg;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Shows your own nametag (IGN, tier tags, totem pops) above your head in third-person (F5), like WhoAmI. */
@Mixin(LivingEntityRenderer.class)
public abstract class OwnNametagMixin {

    @Inject(method = "hasLabel(Lnet/minecraft/entity/LivingEntity;D)Z", at = @At("HEAD"), cancellable = true, require = 0)
    private void ccclient$showOwnLabel(LivingEntity entity, double squaredDistanceToCamera, CallbackInfoReturnable<Boolean> cir) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null || entity != mc.player) return;
        if (!Cfg.on("whoami")) return;
        if (mc.options.hudHidden) {
            cir.setReturnValue(false);
            return;
        }
        if (!mc.options.getPerspective().isFirstPerson()) {
            cir.setReturnValue(true);
        }
    }
}
