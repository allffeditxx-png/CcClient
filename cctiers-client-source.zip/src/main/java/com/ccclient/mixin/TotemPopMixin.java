package com.ccclient.mixin;

import com.ccclient.core.TotemPops;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Entity status 35 is "used a totem of undying". We count it per player. */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class TotemPopMixin {

    @Inject(method = "onEntityStatus", at = @At("TAIL"), require = 0)
    private void ccclient$countPop(EntityStatusS2CPacket packet, CallbackInfo ci) {
        if (packet.getStatus() != 35) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        Entity e = packet.getEntity(mc.world);
        if (e instanceof PlayerEntity p) TotemPops.add(p.getUuid());
    }
}
