package com.ccclient.mixin;

import com.ccclient.core.TpsTracker;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** The server sends a time update every 20 ticks; the gap between them tells us the TPS. */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class TpsMixin {

    @Inject(method = "onWorldTimeUpdate", at = @At("HEAD"), require = 0)
    private void ccclient$timeUpdate(CallbackInfo ci) {
        TpsTracker.onUpdate();
    }
}
