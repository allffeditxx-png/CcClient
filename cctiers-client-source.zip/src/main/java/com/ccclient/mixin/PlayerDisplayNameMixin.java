package com.ccclient.mixin;

import com.ccclient.core.TotemPops;
import com.ccclient.data.TierTags;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** The nametag above a player is rendered from PlayerEntity#getDisplayName. */
@Mixin(PlayerEntity.class)
public abstract class PlayerDisplayNameMixin {

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void ccclient$addTag(CallbackInfoReturnable<Text> cir) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        Text original = cir.getReturnValue();
        Text out = original;
        Text tagged = TierTags.nametag(self, out);
        if (tagged != null) out = tagged;
        Text pops = TotemPops.nametag(self, out);
        if (pops != null) out = pops;
        if (out != original) cir.setReturnValue(out);
    }
}
