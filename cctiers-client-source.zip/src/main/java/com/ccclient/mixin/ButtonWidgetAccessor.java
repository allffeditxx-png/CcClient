package com.ccclient.mixin;

import net.minecraft.client.gui.widget.ButtonWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Lets the main screen run the click action of buttons that other mods (Mod Menu, Replay Mod, Flashback...) add. */
@Mixin(ButtonWidget.class)
public interface ButtonWidgetAccessor {
    @Accessor("onPress")
    ButtonWidget.PressAction ccclient$getOnPress();
}
