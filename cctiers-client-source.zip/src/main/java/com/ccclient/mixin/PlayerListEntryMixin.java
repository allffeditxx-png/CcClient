package com.ccclient.mixin;

import com.ccclient.data.TierTags;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** The tab list draws names from PlayerListEntry#getDisplayName (null for normal players). */
@Mixin(PlayerListEntry.class)
public abstract class PlayerListEntryMixin {

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void ccclient$addTag(CallbackInfoReturnable<Text> cir) {
        PlayerListEntry self = (PlayerListEntry) (Object) this;
        Text original = cir.getReturnValue();
        Text tagged = TierTags.tab(self, original);
        if (tagged != null && tagged != original) cir.setReturnValue(tagged);
    }
}
