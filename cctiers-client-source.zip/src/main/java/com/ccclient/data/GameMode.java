package com.ccclient.data;

import java.util.Locale;

/** Gamemodes of the CCTiers list. Order = order of the cards on the profile screen. */
public enum GameMode {
    /** The API calls this one "vanilla" - it is the Crystal gamemode. */
    CRYSTAL("crystal", "Crystal"),
    UHC("uhc", "UHC"),
    POT("pot", "Pot"),
    NETH_POT("neth_pot", "Neth Pot"),
    SMP("smp", "SMP"),
    SWORD("sword", "Sword"),
    AXE("axe", "Axe"),
    MACE("mace", "Mace"),
    SPEAR_MACE("spearmace", "Spear Mace"),
    DIA_SMP("diasmp", "Dia SMP");

    public final String id;
    public final String display;

    GameMode(String id, String display) {
        this.id = id;
        this.display = display;
    }

    /** Private-use glyph that the cctiers:gm font maps to this mode's icon. */
    public char glyph() {
        return (char) (0xE000 + ordinal());
    }

    public static GameMode fromId(String id) {
        if (id == null) return null;
        for (GameMode m : values()) {
            if (m.id.equalsIgnoreCase(id)) return m;
        }
        return null;
    }

    /** Maps the API's keys to a mode ("vanilla" -> Crystal, "nethop" -> Neth Pot ...). Unknown keys (cart) are ignored. */
    public static GameMode fromKey(String raw) {
        if (raw == null) return null;
        String k = raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
        return switch (k) {
            case "vanilla", "crystal", "crystalpvp", "cpvp", "ogvanilla", "diamondvanilla" -> CRYSTAL;
            case "uhc", "ironuhc" -> UHC;
            case "pot", "potion", "diapot", "diamondpot" -> POT;
            case "nethpot", "nethop", "nethpotion", "netheritepot" -> NETH_POT;
            case "smp", "netheritesmp" -> SMP;
            case "sword", "swordpvp" -> SWORD;
            case "axe", "axepvp" -> AXE;
            case "mace", "macepvp" -> MACE;
            case "spearmace", "spear" -> SPEAR_MACE;
            case "diasmp", "diamondsmp" -> DIA_SMP;
            default -> null;
        };
    }
}
