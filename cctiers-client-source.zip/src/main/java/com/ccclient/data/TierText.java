package com.ccclient.data;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import net.minecraft.text.Text;
import net.minecraft.text.TextCodecs;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;

import java.util.Optional;

public final class TierText {
    private TierText() {}

    private static final String FONT = "ccclient:gm";
    /** The CcTiers logo (your photo) is glyph U+E100 of the ccclient:gm font. */
    public static final char LOGO = '\uE100';

    private static JsonObject part(String text, String color, Boolean bold, boolean icon) {
        JsonObject o = new JsonObject();
        o.addProperty("text", text);
        o.addProperty("color", color);
        if (bold != null) o.addProperty("bold", bold);
        if (icon) o.addProperty("font", FONT);
        return o;
    }

    private static Text parse(JsonArray extra, Text fallback) {
        JsonObject root = new JsonObject();
        root.addProperty("text", "");
        root.add("extra", extra);
        Optional<Text> parsed = TextCodecs.CODEC.parse(JsonOps.INSTANCE, root).result();
        return parsed.orElse(fallback);
    }

    private static String hex(Rank r) {
        return String.format("#%06X", r.color());
    }

    /** "[icon] HT4 | " - goes in front of the name. */
    public static Text prefix(Rank r, boolean icons, boolean logo) {
        JsonArray extra = new JsonArray();
        if (logo) {
            extra.add(part(String.valueOf(LOGO), "white", false, true));
            extra.add(part(" ", "white", false, false));
        }
        if (icons) {
            extra.add(part(String.valueOf(r.mode().glyph()), "white", false, true));
            extra.add(part(" ", "white", false, false));
        }
        extra.add(part(r.label(), hex(r), false, false));
        extra.add(part(" | ", "dark_gray", false, false));
        Text fallback = Text.empty()
                .append(Text.literal(r.label()).styled(s -> s.withColor(TextColor.fromRgb(r.color()))))
                .append(Text.literal(" | ").formatted(Formatting.DARK_GRAY));
        return parse(extra, fallback);
    }

    /** " | LT3 [icon]" - goes behind the name. */
    public static Text suffix(Rank r, boolean icons, boolean logo) {
        JsonArray extra = new JsonArray();
        extra.add(part(" | ", "dark_gray", false, false));
        extra.add(part(r.label(), hex(r), false, false));
        if (icons) {
            extra.add(part(" ", "white", false, false));
            extra.add(part(String.valueOf(r.mode().glyph()), "white", false, true));
        }
        if (logo) {
            extra.add(part(" ", "white", false, false));
            extra.add(part(String.valueOf(LOGO), "white", false, true));
        }
        Text fallback = Text.empty()
                .append(Text.literal(" | ").formatted(Formatting.DARK_GRAY))
                .append(Text.literal(r.label()).styled(s -> s.withColor(TextColor.fromRgb(r.color()))));
        return parse(extra, fallback);
    }

    /** Just the gamemode icon, for the screens. Empty if the font can't be used. */
    public static Text icon(GameMode mode) {
        JsonArray extra = new JsonArray();
        extra.add(part(String.valueOf(mode.glyph()), "white", false, true));
        return parse(extra, Text.empty());
    }
}
