package com.ccclient.data;

import com.ccclient.core.Cfg;

/** The tier tagger's settings, read from the "CcTiers Tag" card (same fields the CCTiers mod had). */
public final class TierCfg {
    public boolean enabled, showNametag, showTab, showChat, showIcons, showLogo, logoRight;
    public boolean showOwnTag, showSecondTier, registerPlayer, registered;
    public String displayMode = "highest";
    public int cacheMinutes = 5;

    private static final String ID = "cctiers_tag";

    public static TierCfg get() {
        TierCfg c = new TierCfg();
        c.enabled = Cfg.on(ID);
        c.showNametag = Cfg.flag(ID, "nametag");
        c.showTab = Cfg.flag(ID, "tab");
        c.showChat = Cfg.flag(ID, "chat");
        c.showIcons = Cfg.flag(ID, "icons");
        c.showLogo = Cfg.flag(ID, "logo");
        c.logoRight = Cfg.val(ID, "pos") == 1;
        c.showOwnTag = Cfg.flag(ID, "own");
        c.showSecondTier = Cfg.flag(ID, "second");
        c.registerPlayer = Cfg.flag(ID, "register");
        c.registered = Cfg.val(ID, "registered") != 0;
        int m = Cfg.val(ID, "mode");
        GameMode[] modes = GameMode.values();
        c.displayMode = (m >= 1 && m <= modes.length) ? modes[m - 1].id : "highest";
        return c;
    }

    public static void markRegistered() {
        Cfg.setVal(ID, "registered", 1);
        Cfg.save();
    }
}
