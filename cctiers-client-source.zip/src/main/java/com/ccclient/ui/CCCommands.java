package com.ccclient.ui;

import com.ccclient.CCClient;
import com.ccclient.core.Cfg;
import com.ccclient.core.TotemPops;
import com.ccclient.data.TierApi;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** /ccclient opens the menu. /cctiers works like the CCTiers mod's command. */
public final class CCCommands {
    private CCCommands() {}

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher, CommandRegistryAccess access) {
        dispatcher.register(ClientCommandManager.literal("ccclient").executes(ctx -> {
            CCClient.openNextTick(() -> new MenuScreen(null));
            return 1;
        }));

        dispatcher.register(ClientCommandManager.literal("totemreset")
                .executes(ctx -> {
                    TotemPops.reset();
                    ctx.getSource().sendFeedback(Text.literal("Totem pop counters reset."));
                    return 1;
                })
                .then(ClientCommandManager.argument("player", StringArgumentType.word())
                        .suggests((ctx, builder) -> CommandSource.suggestMatching(onlineNames(), builder))
                        .executes(ctx -> {
                            String name = StringArgumentType.getString(ctx, "player");
                            boolean ok = TotemPops.reset(name);
                            ctx.getSource().sendFeedback(Text.literal(ok ? "Reset the counter of " + name + "." : "No player called " + name + " is nearby."));
                            return 1;
                        })));

        dispatcher.register(ClientCommandManager.literal("cctiers")
                .executes(ctx -> {
                    ctx.getSource().sendFeedback(Text.literal("CcTiers - /cctiers <player>, /cctiers config, /cctiers toggle, /cctiers refresh, /cctiers register"));
                    return 1;
                })
                .then(ClientCommandManager.literal("config").executes(ctx -> {
                    CCClient.openNextTick(() -> new MenuScreen(null));
                    return 1;
                }))
                .then(ClientCommandManager.literal("refresh").executes(ctx -> {
                    TierApi.clear();
                    ctx.getSource().sendFeedback(Text.literal("CcTiers: cache cleared, tiers will reload."));
                    return 1;
                }))
                .then(ClientCommandManager.literal("register").executes(ctx -> {
                    CCClient.registerNow(MinecraftClient.getInstance());
                    ctx.getSource().sendFeedback(Text.literal("CcTiers: registering you on the API..."));
                    return 1;
                }))
                .then(ClientCommandManager.literal("toggle").executes(ctx -> {
                    boolean now = !Cfg.on("cctiers_tag");
                    Cfg.setOn("cctiers_tag", now);
                    ctx.getSource().sendFeedback(Text.literal("CcTiers tags: " + (now ? "ON" : "OFF")));
                    return 1;
                }))
                .then(ClientCommandManager.argument("player", StringArgumentType.word())
                        .suggests((ctx, builder) -> CommandSource.suggestMatching(onlineNames(), builder))
                        .executes(ctx -> {
                            String name = StringArgumentType.getString(ctx, "player");
                            CCClient.openNextTick(() -> new ProfileScreen(name, null));
                            return 1;
                        })));
    }

    private static List<String> onlineNames() {
        List<String> names = new ArrayList<>();
        ClientPlayNetworkHandler handler = MinecraftClient.getInstance().getNetworkHandler();
        if (handler != null) {
            for (PlayerListEntry e : handler.getPlayerList()) {
                names.add(e.getProfile().name());
            }
        }
        return names;
    }
}
