package com.ccclient.ui;

import com.ccclient.core.Accounts;
import com.ccclient.data.GameMode;
import com.ccclient.data.Profile;
import com.ccclient.data.Rank;
import com.ccclient.data.TierApi;
import com.ccclient.data.TierText;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Our main screen: your photo as a slowly moving background, tiers on top, nicer buttons, and every button other mods add. */
public class CCTitleScreen extends Screen {
    private final Pad pad = new Pad();
    private final float[] hv = new float[40];
    private long lastNs = System.nanoTime();
    private long openedNs = System.nanoTime();
    private List<ModButtons.Entry> mods = new ArrayList<>();
    private boolean shiftPrev = false;
    private int btnIndex = 0;

    // block letters for the logo (5 x 7)
    private static final String[] GLYPH_C = {".XXX.", "X...X", "X....", "X....", "X....", "X...X", ".XXX."};
    private static final String[] GLYPH_I = {"XXXXX", "..X..", "..X..", "..X..", "..X..", "..X..", "XXXXX"};
    private static final String[] GLYPH_E = {"XXXXX", "X....", "X....", "XXXX.", "X....", "X....", "XXXXX"};
    private static final String[] GLYPH_T = {"XXXXX", "..X..", "..X..", "..X..", "..X..", "..X..", "..X.."};
    private static final String[] GLYPH_R = {"XXXX.", "X...X", "X...X", "XXXX.", "X.X..", "X..X.", "X...X"};
    private static final String[] GLYPH_S = {".XXXX", "X....", "X....", ".XXX.", "....X", "....X", "XXXX."};

    public CCTitleScreen(List<ModButtons.Entry> modButtons) {
        super(Text.literal("CcTiers Client"));
        this.mods = modButtons == null ? new ArrayList<>() : modButtons;
    }

    @Override
    protected void init() {
        long win = this.client.getWindow().getHandle();
        pad.sync(win);
        shiftPrev = Pad.key(win, GLFW.GLFW_KEY_RIGHT_SHIFT);
        openedNs = System.nanoTime();
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        MinecraftClient mc = this.client;
        TextRenderer tr = this.textRenderer;
        long win = mc.getWindow().getHandle();
        pad.poll(win);
        long nowNs = System.nanoTime();
        float dt = Math.min(0.1f, (nowNs - lastNs) / 1_000_000_000f);
        lastNs = nowNs;
        btnIndex = 0;

        Backdrop.draw(ctx, this.width, this.height, System.currentTimeMillis() / 1000.0);

        boolean sh = Pad.key(win, GLFW.GLFW_KEY_RIGHT_SHIFT);
        if (sh && !shiftPrev) {
            shiftPrev = true;
            mc.setScreen(new MenuScreen(this));
            return;
        }
        shiftPrev = sh;

        int y = drawTiers(ctx, tr, mc, mx, my) + 8;

        // logo picture + block letters
        int px = this.height >= 250 ? 4 : this.height >= 190 ? 3 : 2;
        String[][] letters = {GLYPH_C, GLYPH_C, GLYPH_T, GLYPH_I, GLYPH_E, GLYPH_R, GLYPH_S};
        int logoSize = 7 * px;
        int lettersW = letters.length * 5 * px + (letters.length - 1) * px;
        int totalW = logoSize + px * 2 + lettersW;
        int lx = (this.width - totalW) / 2;
        Backdrop.logo(ctx, lx, y, logoSize);
        lx += logoSize + px * 2;
        for (String[] g : letters) {
            for (int r = 0; r < 7; r++) {
                for (int c = 0; c < 5; c++) {
                    if (g[r].charAt(c) != 'X') continue;
                    int bx = lx + c * px, by = y + r * px;
                    ctx.fill(bx + 1, by + 1, bx + px + 1, by + px + 1, 0xAA000000);
                    ctx.fill(bx, by, bx + px, by + px, Gfx.GOLD);
                    ctx.fill(bx, by, bx + px, by + 1, Gfx.GOLD_LIGHT);
                }
            }
            lx += 6 * px;
        }
        y += 7 * px + 3;
        Gfx.center(ctx, tr, "C  L  I  E  N  T", this.width / 2, y, Gfx.GOLD_LIGHT);
        y += 14;

        // buttons
        int nSec = 2 + mods.size();
        int secRows = (nSec + 1) / 2;
        int bh = 22, sh2 = 18, gap = 4;
        int avail = this.height - y - 16;
        int need = 2 * (bh + gap) + (secRows + 1) * (sh2 + gap);
        if (need > avail) {
            bh = 18;
            sh2 = 15;
            gap = 2;
        }
        int bw = Math.min(210, this.width - 24);
        int bx = (this.width - bw) / 2;
        int half = (bw - gap) / 2;

        button(ctx, tr, "Singleplayer", bx, y, bw, bh, mx, my, dt, () -> mc.setScreen(new SelectWorldScreen(this)));
        y += bh + gap;
        button(ctx, tr, "Multiplayer", bx, y, bw, bh, mx, my, dt, () -> mc.setScreen(new MultiplayerScreen(this)));
        y += bh + gap;

        List<String> labels = new ArrayList<>();
        List<Runnable> actions = new ArrayList<>();
        labels.add("Options");
        actions.add(() -> mc.setScreen(new OptionsScreen(this, mc.options)));
        labels.add("Account Switcher");
        actions.add(() -> mc.setScreen(new AccountScreen(this)));
        for (ModButtons.Entry e : mods) {
            labels.add(e.label);
            actions.add(e.action);
        }
        for (int i = 0; i < labels.size(); i += 2) {
            boolean last = i + 1 >= labels.size();
            if (last) {
                button(ctx, tr, labels.get(i), bx, y, bw, sh2, mx, my, dt, actions.get(i));
            } else {
                button(ctx, tr, labels.get(i), bx, y, half, sh2, mx, my, dt, actions.get(i));
                button(ctx, tr, labels.get(i + 1), bx + half + gap, y, half, sh2, mx, my, dt, actions.get(i + 1));
            }
            y += sh2 + gap;
        }
        button(ctx, tr, "Quit Game", bx, y, bw, sh2, mx, my, dt, mc::scheduleStop);

        // footer
        Gfx.text(ctx, tr, "Playing as " + Accounts.currentName(), 6, this.height - 24, 0xDDFFFFFF);
        Gfx.text(ctx, tr, "CcTiers Client by AyushXDP", 6, this.height - 12, 0xAAFFFFFF);
        String ver = "Minecraft 1.21.11";
        Gfx.text(ctx, tr, ver, this.width - 6 - tr.getWidth(ver), this.height - 12, 0xAAFFFFFF);

        String themeLabel = "UI: " + Gfx.themeName();
        int tw = tr.getWidth(themeLabel) + 12;
        int tx = this.width - 6 - tw, ty = this.height - 29;
        boolean thov = Gfx.inside(mx, my, tx, ty, tw, 13);
        Gfx.button(ctx, tr, tx, ty, tw, 13, themeLabel, thov, false);
        if (thov && pad.lRelease()) Gfx.toggleTheme();
    }

    /** One of our buttons: dark glass, thin outline, gold accent that grows on hover, slides in when the screen opens. */
    private void button(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w, int h, int mx, int my, float dt, Runnable action) {
        int idx = Math.min(btnIndex++, hv.length - 1);
        double secs = (System.nanoTime() - openedNs) / 1e9 - idx * 0.05;
        float e = (float) Math.max(0, Math.min(1, secs / 0.35));
        float ease = 1f - (1f - e) * (1f - e) * (1f - e);
        if (ease <= 0f) return;
        int ox = Math.round((1f - ease) * -36f);
        int rx = x + ox;

        boolean hov = Gfx.inside(mx, my, x, y, w, h) && ease >= 1f;
        hv[idx] += ((hov ? 1f : 0f) - hv[idx]) * Math.min(1f, dt * 14f);
        float a = hv[idx];

        Gfx.round(ctx, rx, y, w, h, Gfx.mix(Gfx.BTN, Gfx.BTN_HOVER, a));
        Gfx.outline(ctx, rx, y, w, h, Gfx.mix(Gfx.GOLD_DARK & 0x00FFFFFF | 0x88000000, Gfx.GOLD, a));
        ctx.fill(rx + 1, y + 2, rx + 3, y + h - 2, Gfx.GOLD);
        int bar = Math.round((w - 6) * a);
        if (bar > 0) ctx.fill(rx + 3, y + h - 3, rx + 3 + bar, y + h - 2, Gfx.GOLD_LIGHT);
        int tc = Gfx.mix(Gfx.TEXT, Gfx.GOLD_LIGHT, a);
        ctx.drawText(tr, label, rx + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2 + 1, tc, false);

        if (hov && pad.lRelease()) action.run();
    }

    /** Tier strip at the top. Click it to open your profile. Returns the y where it ends. */
    private int drawTiers(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int mx, int my) {
        String name = Accounts.currentName();
        int pw = Math.min(this.width - 12, 470);
        int px = (this.width - pw) / 2, py = 6;

        TierApi.Entry e = TierApi.get(name);
        GameMode[] modes = GameMode.values();
        boolean ready = e != null && e.state == TierApi.State.READY && e.profile != null;

        int chipW = 40, chipH = 14, cgap = 3;
        int perRow = Math.max(1, (pw - 10 + cgap) / (chipW + cgap));
        int rows = ready ? (modes.length + perRow - 1) / perRow : 0;
        int ph = 18 + rows * (chipH + cgap) + (ready ? 2 : 0);

        boolean hov = ready && Gfx.inside(mx, my, px, py, pw, ph);
        Gfx.round(ctx, px, py, pw, ph, hov ? 0xAA14110A : 0x99000000);
        Gfx.outline(ctx, px, py, pw, ph, hov ? Gfx.GOLD : Gfx.GOLD_DARK);
        Backdrop.logo(ctx, px + 4, py + 3, 12);
        String shown = name.isEmpty() ? "Player" : name;
        Gfx.text(ctx, tr, shown, px + 20, py + 5, Gfx.GOLD);
        int nameW = tr.getWidth(shown);

        String info;
        if (e == null) info = "Tiers need a valid username";
        else if (e.state == TierApi.State.LOADING) info = "Loading tiers...";
        else if (e.state == TierApi.State.ERROR) info = "Can't reach the tier server";
        else if (e.state == TierApi.State.NOT_FOUND) info = "Not on CcTiers yet";
        else {
            Profile p = e.profile;
            info = (p.region == null || p.region.isEmpty() ? "" : "Region " + p.region + "  |  ") + "Overall #" + (p.overall > 0 ? p.overall : "-") + "  |  " + p.points + " pts";
        }
        Gfx.text(ctx, tr, info, px + 28 + nameW, py + 5, Gfx.TEXT);

        if (ready) {
            Profile p = e.profile;
            int total = Math.min(modes.length, perRow);
            int rowW = total * chipW + (total - 1) * cgap;
            int sx = px + (pw - rowW) / 2;
            for (int i = 0; i < modes.length; i++) {
                int cx = sx + (i % perRow) * (chipW + cgap);
                int cy = py + 18 + (i / perRow) * (chipH + cgap);
                Rank r = p.forMode(modes[i]);
                int accent = r == null ? 0xFF444444 : (0xFF000000 | r.color());
                Gfx.round(ctx, cx, cy, chipW, chipH, 0xCC0C0C0C);
                Gfx.rect(ctx, cx, cy + chipH - 2, chipW, 2, accent);
                ctx.drawTextWithShadow(tr, TierText.icon(modes[i]), cx + 3, cy + 2, 0xFFFFFFFF);
                ctx.drawTextWithShadow(tr, r == null ? "-" : r.label(), cx + 16, cy + 3, accent);
            }
            if (hov && pad.lRelease()) mc.setScreen(new ProfileScreen(name, this));
        }
        return py + ph;
    }
}
