package com.ccclient.ui;

import com.ccclient.core.Cfg;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Small drawing helpers (only plain fills + text, so they work on any GUI scale). */
public final class Gfx {
    private Gfx() {}

    // ---- theme (0 = Black & Gold, 1 = Normal). The colours below are re-assigned by applyTheme().
    public static int BG = 0xF00A0A0A;
    public static int PANEL = 0xF0141414;
    public static int CARD = 0xF01C1A14;
    public static int CARD_HOVER = 0xF028241A;
    public static int GOLD = 0xFFC8A03C;
    public static int GOLD_LIGHT = 0xFFE2C377;
    public static int GOLD_DARK = 0xFF6E5A24;
    public static int TEXT = 0xFFEDE4CC;
    public static int DIM = 0xFF9C9276;
    public static int OFF = 0xFF35322A;
    public static int BTN = 0xB0000000;
    public static int BTN_HOVER = 0xD0221D12;
    public static int ON_TEXT = 0xFF15110A;

    public static int theme() {
        return Cfg.val("ui", "theme");
    }

    public static String themeName() {
        return theme() == 0 ? "Black & Gold" : "Normal";
    }

    public static void toggleTheme() {
        Cfg.setVal("ui", "theme", theme() == 0 ? 1 : 0);
        applyTheme();
        Cfg.save();
    }

    public static void applyTheme() {
        if (theme() == 0) {
            BG = 0xF00A0A0A; PANEL = 0xF0141414; CARD = 0xF01C1A14; CARD_HOVER = 0xF028241A;
            GOLD = 0xFFC8A03C; GOLD_LIGHT = 0xFFE2C377; GOLD_DARK = 0xFF6E5A24;
            TEXT = 0xFFEDE4CC; DIM = 0xFF9C9276; OFF = 0xFF35322A;
            BTN = 0xB0000000; BTN_HOVER = 0xD0221D12; ON_TEXT = 0xFF15110A;
        } else {
            BG = 0xF0101010; PANEL = 0xF01E1E1E; CARD = 0xF02A2A2A; CARD_HOVER = 0xF0383838;
            GOLD = 0xFFB5B5B5; GOLD_LIGHT = 0xFFFFFFFF; GOLD_DARK = 0xFF5A5A5A;
            TEXT = 0xFFFFFFFF; DIM = 0xFFA0A0A0; OFF = 0xFF3C3C3C;
            BTN = 0xB0000000; BTN_HOVER = 0xD0505050; ON_TEXT = 0xFF101010;
        }
    }

    /** Blends two ARGB colours (t = 0 gives a, t = 1 gives b). */
    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = a >>> 24, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = b >>> 24, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    public static void rect(DrawContext c, int x, int y, int w, int h, int argb) {
        c.fill(x, y, x + w, y + h, argb);
    }

    /** Rectangle with the four corner pixels cut off. */
    public static void round(DrawContext c, int x, int y, int w, int h, int argb) {
        c.fill(x + 1, y, x + w - 1, y + h, argb);
        c.fill(x, y + 1, x + w, y + h - 1, argb);
    }

    public static void outline(DrawContext c, int x, int y, int w, int h, int argb) {
        c.fill(x + 1, y, x + w - 1, y + 1, argb);
        c.fill(x + 1, y + h - 1, x + w - 1, y + h, argb);
        c.fill(x, y + 1, x + 1, y + h - 1, argb);
        c.fill(x + w - 1, y + 1, x + w, y + h - 1, argb);
    }

    public static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    public static void text(DrawContext c, TextRenderer tr, String s, int x, int y, int color) {
        c.drawTextWithShadow(tr, s, x, y, color);
    }

    public static void center(DrawContext c, TextRenderer tr, String s, int cx, int y, int color) {
        c.drawTextWithShadow(tr, s, cx - tr.getWidth(s) / 2, y, color);
    }

    /** Pill button used all over the menu. Returns nothing - hit testing is done by the caller. */
    public static void button(DrawContext c, TextRenderer tr, int x, int y, int w, int h, String label, boolean hover, boolean active) {
        int bg = active ? (hover ? GOLD_LIGHT : GOLD) : (hover ? mix(OFF, GOLD_DARK, 0.6f) : OFF);
        round(c, x, y, w, h, bg);
        int tc = active ? ON_TEXT : TEXT;
        c.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2 + 1, tc, false);
    }

    /** Wraps text to a pixel width. */
    public static List<String> wrap(TextRenderer tr, String s, int width) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String trial = line.length() == 0 ? word : line + " " + word;
            if (tr.getWidth(trial) > width && line.length() > 0) {
                out.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(trial);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }
}
