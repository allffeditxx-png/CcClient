package com.ccclient.ui;

import com.ccclient.core.Accounts;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** In-game account changer. */
public class AccountScreen extends Screen {
    private final Screen parent;
    private final Pad pad = new Pad();
    private TextFieldWidget field;
    private float scroll = 0;
    private String status = "";
    private int statusColor = 0xFFFFFFFF;

    private static final class Btn {
        final int x, y, w, h;
        final Runnable run;
        final int[] clip;

        Btn(int x, int y, int w, int h, Runnable run, int[] clip) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.run = run;
            this.clip = clip;
        }

        boolean contains(int mx, int my) {
            return Gfx.inside(mx, my, x, y, w, h) && (clip == null || Gfx.inside(mx, my, clip[0], clip[1], clip[2], clip[3]));
        }
    }

    private final List<Btn> btns = new ArrayList<>();

    public AccountScreen(Screen parent) {
        super(Text.literal("Accounts"));
        this.parent = parent;
    }

    private int pw() {
        return Math.min(this.width - 8, 320);
    }

    private int ph() {
        return Math.min(this.height - 8, 230);
    }

    @Override
    protected void init() {
        pad.sync(this.client.getWindow().getHandle());
        int pw = pw(), ph = ph();
        int px = (this.width - pw) / 2, py = (this.height - ph) / 2;
        field = new TextFieldWidget(this.textRenderer, px + 8, py + ph - 56, pw - 16 - 54, 16, Text.literal("Username"));
        field.setMaxLength(16);
        this.addSelectableChild(field);
        field.setFocused(true);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll -= (float) verticalAmount * 18f;
        return true;
    }

    private void say(String msg, boolean ok) {
        status = msg;
        statusColor = ok ? 0xFF7CE08A : 0xFFFF7777;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        pad.poll(this.client.getWindow().getHandle());
        TextRenderer tr = this.textRenderer;
        btns.clear();

        if (this.client.world == null) Backdrop.draw(ctx, this.width, this.height, System.currentTimeMillis() / 1000.0);
        ctx.fill(0, 0, this.width, this.height, this.client.world == null ? 0x66000000 : 0xA0000000);

        int pw = pw(), ph = ph();
        int px = (this.width - pw) / 2, py = (this.height - ph) / 2;
        Gfx.round(ctx, px, py, pw, ph, Gfx.PANEL);
        Gfx.outline(ctx, px, py, pw, ph, Gfx.GOLD_DARK);
        Gfx.rect(ctx, px + 1, py + 1, pw - 2, 2, Gfx.GOLD);
        Gfx.text(ctx, tr, "Accounts", px + 8, py + 8, Gfx.GOLD);

        String current = Accounts.currentName();
        Gfx.text(ctx, tr, "Playing as: " + current, px + 8, py + 22, Gfx.TEXT);

        // launcher account row
        String orig = Accounts.originalName();
        int rowY = py + 36;
        if (!orig.isEmpty() && !orig.equals(current)) {
            Gfx.text(ctx, tr, "Launcher account: " + orig, px + 8, rowY + 3, Gfx.DIM);
            small(ctx, tr, "Use", px + pw - 8 - 40, rowY, 40, mx, my, () -> {
                String err = Accounts.useOriginal(this.client);
                if (err == null) say("Switched to " + Accounts.currentName(), true);
                else say(err, false);
            }, null);
        }

        // saved list
        int listTop = py + 52, listBottom = py + ph - 62;
        int[] clip = {px + 4, listTop, pw - 8, listBottom - listTop};
        List<String> saved = Accounts.list();
        int total = saved.size() * 18;
        int maxScroll = Math.max(0, total - (listBottom - listTop));
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        ctx.enableScissor(clip[0], clip[1], clip[0] + clip[2], clip[1] + clip[3]);
        if (saved.isEmpty()) Gfx.text(ctx, tr, "No saved accounts yet", px + 10, listTop + 4, Gfx.DIM);
        for (int i = 0; i < saved.size(); i++) {
            String n = saved.get(i);
            int y = listTop + i * 18 - (int) scroll;
            boolean isCur = n.equalsIgnoreCase(current);
            Gfx.round(ctx, px + 8, y, pw - 16, 16, isCur ? Gfx.CARD_HOVER : Gfx.CARD);
            if (isCur) Gfx.rect(ctx, px + 8, y, 2, 16, Gfx.GOLD);
            Gfx.text(ctx, tr, n, px + 14, y + 4, isCur ? Gfx.GOLD_LIGHT : Gfx.TEXT);
            small(ctx, tr, "Use", px + pw - 8 - 22 - 40 - 2, y + 1, 40, mx, my, () -> {
                String err = Accounts.switchTo(this.client, n);
                if (err == null) say("Switched to " + n, true);
                else say(err, false);
            }, clip);
            small(ctx, tr, "X", px + pw - 8 - 22, y + 1, 20, mx, my, () -> Accounts.remove(n), clip);
        }
        ctx.disableScissor();

        // add row
        field.render(ctx, mx, my, delta);
        small(ctx, tr, "Add", px + pw - 8 - 50, py + ph - 56, 50, mx, my, () -> {
            String name = field.getText().trim();
            String err = Accounts.add(name);
            if (err == null) {
                field.setText("");
                say("Saved " + name, true);
            } else {
                say(err, false);
            }
        }, null);

        if (!status.isEmpty()) Gfx.text(ctx, tr, status, px + 8, py + ph - 34, statusColor);

        int bw = 80;
        boolean hov = Gfx.inside(mx, my, px + (pw - bw) / 2, py + ph - 20, bw, 14);
        Gfx.button(ctx, tr, px + (pw - bw) / 2, py + ph - 20, bw, 14, "Done", hov, true);
        btns.add(new Btn(px + (pw - bw) / 2, py + ph - 20, bw, 14, this::close, null));

        if (pad.lRelease()) {
            for (int i = btns.size() - 1; i >= 0; i--) {
                Btn b = btns.get(i);
                if (b.contains(mx, my)) {
                    b.run.run();
                    break;
                }
            }
        }
    }

    private void small(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w, int mx, int my, Runnable r, int[] clip) {
        boolean hov = Gfx.inside(mx, my, x, y, w, 14) && (clip == null || Gfx.inside(mx, my, clip[0], clip[1], clip[2], clip[3]));
        Gfx.button(ctx, tr, x, y, w, 14, label, hov, false);
        btns.add(new Btn(x, y, w, 14, r, clip));
    }
}
