package com.ccclient.ui;

import com.ccclient.mixin.ButtonWidgetAccessor;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TexturedButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Other mods (Mod Menu, Replay Mod, Flashback ...) add their buttons to the vanilla title screen.
 * The game opens the vanilla title screen first and those mods add their buttons to it; we copy every
 * extra button into our own screen. Everything is wrapped so a misbehaving mod can never crash us.
 */
public final class ModButtons {
    private ModButtons() {}

    public static final class Entry {
        public final String label;
        public final Runnable action;

        Entry(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }
    }

    private static final String[] VANILLA_KEYS = {
            "menu.singleplayer", "menu.multiplayer", "menu.online", "menu.options", "menu.quit",
            "menu.playdemo", "menu.resetdemo", "narrator.button.language", "narrator.button.accessibility",
            "title.credits", "title.multiplayer.disabled", "title.multiplayer.realms.disabled"
    };

    /** Copies the extra buttons out of the vanilla title screen the game has just opened (before we replace it). */
    public static List<Entry> harvest(TitleScreen donor) {
        List<Entry> out = new ArrayList<>();
        try {
            Set<String> vanilla = new HashSet<>();
            for (String k : VANILLA_KEYS) vanilla.add(Text.translatable(k).getString());

            Set<String> seen = new HashSet<>();
            for (Element e : donor.children()) {
                try {
                    if (!(e instanceof ButtonWidget b) || e instanceof TexturedButtonWidget) continue;
                    String label = b.getMessage().getString();
                    if (label.isEmpty() || vanilla.contains(label) || label.contains("Copyright") || !seen.add(label)) continue;
                    ButtonWidget.PressAction act = ((ButtonWidgetAccessor) (Object) b).ccclient$getOnPress();
                    if (act == null) continue;
                    out.add(new Entry(label, () -> {
                        try {
                            act.onPress(b);
                        } catch (Throwable ignored) {
                        }
                    }));
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }
}
