package com.ccclient.ui;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/** Your photo as the main-screen background. It pans slowly, like the vanilla panorama. */
public final class Backdrop {
    private Backdrop() {}

    public static final Identifier TEX = Identifier.of("ccclient", "textures/gui/title.png");
    public static final Identifier LOGO = Identifier.of("ccclient", "textures/font/cclogo.png");
    private static final int TW = 1280, TH = 720;

    public static void draw(DrawContext c, int w, int h, double t) {
        double aspect = (double) w / Math.max(1, h);
        int rh = TH;
        int rw = (int) Math.round(TH * aspect);
        if (rw > TW) {
            rw = TW;
            rh = (int) Math.round(TW / aspect);
        }
        // look at 84% of the picture and drift around inside it
        rw = (int) (rw * 0.84);
        rh = (int) (rh * 0.84);
        float u = (float) ((TW - rw) * (0.5 + 0.5 * Math.sin(t * 0.07)));
        float v = (float) ((TH - rh) * (0.5 + 0.5 * Math.sin(t * 0.045 + 1.3)));
        c.drawTexture(RenderPipelines.GUI_TEXTURED, TEX, 0, 0, u, v, w, h, rw, rh, TW, TH);

        // soft shading so buttons and text stay readable
        c.fillGradient(0, 0, w, (int) (h * 0.22), 0xA0000000, 0x00000000);
        c.fillGradient(0, (int) (h * 0.45), w, h, 0x00000000, 0xB0000000);
        if (Gfx.theme() == 0) c.fill(0, 0, w, h, 0x28100A00);
    }

    public static void logo(DrawContext c, int x, int y, int size) {
        c.drawTexture(RenderPipelines.GUI_TEXTURED, LOGO, x, y, 0f, 0f, size, size, 128, 128, 128, 128);
    }
}
