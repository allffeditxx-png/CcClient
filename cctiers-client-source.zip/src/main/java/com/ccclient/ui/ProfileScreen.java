package com.ccclient.ui;

import com.ccclient.data.GameMode;
import com.ccclient.data.Profile;
import com.ccclient.data.Rank;
import com.ccclient.data.TierApi;
import com.ccclient.data.TierText;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Util;

import java.net.URI;

/** /cctiers <player> and the tier strip on the main screen: the player search result screen. */
public class ProfileScreen extends Screen {
    private final String name;
    private final Screen parent;

    public ProfileScreen(String name, Screen parent) {
        super(Text.literal("CcTiers"));
        this.name = name;
        this.parent = parent;
        TierApi.refresh(); // always show fresh data on the search screen
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height - 26;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("NameMC"), b -> {
            try {
                Util.getOperatingSystem().open(URI.create("https://namemc.com/profile/" + name));
            } catch (Exception ignored) {
            }
        }).dimensions(cx - 102, y, 100, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> this.close())
                .dimensions(cx + 2, y, 100, 20).build());
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (this.client.world == null) {
            Backdrop.draw(ctx, this.width, this.height, System.currentTimeMillis() / 1000.0);
            ctx.fill(0, 0, this.width, this.height, 0x88000000);
        }
        super.render(ctx, mouseX, mouseY, delta);
        int cx = this.width / 2;
        TierApi.Entry entry = TierApi.get(name);

        if (entry == null || entry.state == TierApi.State.NOT_FOUND) {
            title(ctx, name, cx);
            center(ctx, "Player not found on CcTiers", cx, this.height / 2, 0xFFFF7777);
            return;
        }
        if (entry.state == TierApi.State.LOADING) {
            title(ctx, name, cx);
            center(ctx, "Loading...", cx, this.height / 2, 0xFFAAAAAA);
            return;
        }
        if (entry.state == TierApi.State.ERROR || entry.profile == null) {
            title(ctx, name, cx);
            center(ctx, "Could not reach the CcTiers API (" + entry.error + ")", cx, this.height / 2, 0xFFFF7777);
            return;
        }

        Profile p = entry.profile;
        title(ctx, p.name, cx);
        String info = (p.region == null || p.region.isEmpty() ? "" : "Region " + p.region + "   |   ")
                + "Overall #" + (p.overall > 0 ? p.overall : "-") + "   |   " + p.points + " points";
        center(ctx, info, cx, 25, Gfx.GOLD_LIGHT);

        int cols = this.width >= 330 ? 3 : 2;
        int gap = 4;
        int cardW = Math.min(104, (this.width - 16 - gap * (cols - 1)) / cols);
        int cardH = 28;
        int totalW = cols * cardW + (cols - 1) * gap;
        int left = cx - totalW / 2;
        int top = 40;

        GameMode[] modes = GameMode.values();
        for (int i = 0; i < modes.length; i++) {
            int x = left + (i % cols) * (cardW + gap);
            int y = top + (i / cols) * (cardH + gap);
            drawCard(ctx, modes[i], p.forMode(modes[i]), x, y, cardW, cardH);
        }
    }

    private void title(DrawContext ctx, String text, int cx) {
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(text).formatted(Formatting.BOLD), cx, 11, Gfx.GOLD);
    }

    private void center(DrawContext ctx, String text, int cx, int y, int color) {
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(text), cx, y, color);
    }

    private void drawCard(DrawContext ctx, GameMode mode, Rank r, int x, int y, int w, int h) {
        int accent = r == null ? 0xFF444444 : (0xFF000000 | r.color());
        ctx.fill(x, y, x + w, y + h, 0xC0101010);
        ctx.fill(x, y, x + 2, y + h, accent);

        ctx.drawTextWithShadow(this.textRenderer, TierText.icon(mode), x + 6, y + 4, 0xFFFFFFFF);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(mode.display), x + 20, y + 4, 0xFFFFFFFF);

        if (r == null) {
            ctx.drawTextWithShadow(this.textRenderer, Text.literal("Unranked"), x + 6, y + 16, 0xFF777777);
            return;
        }
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(r.label()), x + 6, y + 16, accent);
    }
}
