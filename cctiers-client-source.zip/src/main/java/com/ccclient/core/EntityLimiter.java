package com.ccclient.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Entity Limiter: in a chunk with more than N entities (armor stands, minecarts, items...) only the N closest to you are drawn.
 * The list of hidden entities is rebuilt a few times per second, so rendering itself only does one cheap lookup.
 * Hidden entities are still there - you can still be hit by them, they just aren't drawn.
 */
public final class EntityLimiter {
    private EntityLimiter() {}

    private static volatile Set<Integer> hidden = new HashSet<>();
    private static final String ID = "entity_limit";

    /** Called from the render mixin for every entity. */
    public static boolean isHidden(int entityId) {
        Set<Integer> h = hidden;
        return !h.isEmpty() && h.contains(entityId);
    }

    /** Every 4 client ticks. */
    public static void update(MinecraftClient mc) {
        if (!Cfg.on(ID) || mc.world == null || mc.player == null) {
            if (!hidden.isEmpty()) hidden = new HashSet<>();
            return;
        }
        int cap = Cfg.val(ID, "cap");
        double near = Cfg.val(ID, "near");
        double near2 = near * near;
        double cx = mc.player.getX(), cy = mc.player.getY(), cz = mc.player.getZ();
        Entity target = mc.targetedEntity;

        Map<Long, List<Entity>> groups = new HashMap<>();
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof PlayerEntity || e == target || e == mc.cameraEntity) continue;
            if (e.squaredDistanceTo(cx, cy, cz) <= near2) continue;
            long key = ((long) (e.getBlockX() >> 4) & 0xFFFFFFFFL) | (((long) (e.getBlockZ() >> 4) & 0xFFFFFFFFL) << 32);
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(e);
        }

        Set<Integer> next = new HashSet<>();
        for (List<Entity> list : groups.values()) {
            if (list.size() <= cap) continue;
            list.sort((a, b) -> Double.compare(a.squaredDistanceTo(cx, cy, cz), b.squaredDistanceTo(cx, cy, cz)));
            for (int i = cap; i < list.size(); i++) next.add(list.get(i).getId());
        }
        hidden = next;
    }

    public static void clear() {
        hidden = new HashSet<>();
    }
}
