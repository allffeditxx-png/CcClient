package com.ccclient.core;

import com.ccclient.core.Mod.Cat;
import com.ccclient.data.GameMode;

/** Every card in the menu. Call Mods.init() once. */
public final class Mods {
    private Mods() {}

    private static boolean done = false;

    public static void init() {
        if (done) return;
        done = true;

        // ---------------------------------------------------------------- info
        new Mod("fps", "FPS", "Your frame rate.", Cat.INFO, true, true, 0.01f, 0.02f).common();
        new Mod("coords", "Coordinates", "Your X, Y and Z position.", Cat.INFO, true, true, 0.01f, 0.09f)
                .opt(Opt.integer("decimals", "Decimals", 0, 2, 1, 0)).common();
        new Mod("biome", "Biome", "The biome you are standing in.", Cat.INFO, false, true, 0.01f, 0.16f).common();
        new Mod("direction", "Direction", "Which way you are facing.", Cat.INFO, false, true, 0.01f, 0.23f)
                .opt(Opt.bool("degrees", "Show degrees", false)).common();
        new Mod("clock", "Clock", "Real time clock.", Cat.INFO, false, true, 0.80f, 0.30f)
                .opt(Opt.choice("fmt", "Format", 0, "24h", "12h"))
                .opt(Opt.bool("seconds", "Show seconds", false)).common();
        new Mod("memory", "Memory Usage", "Game memory in use.", Cat.INFO, false, true, 0.80f, 0.16f)
                .opt(Opt.choice("mode", "Show", 0, "Used / Max", "Percent")).common();
        new Mod("tps", "TPS", "Server ticks per second (estimated).", Cat.INFO, false, true, 0.80f, 0.09f).common();
        new Mod("ping", "Ping", "Your latency to the server.", Cat.INFO, true, true, 0.80f, 0.02f).common();
        new Mod("day", "Day Counter", "How many days the world has run.", Cat.INFO, false, true, 0.01f, 0.30f).common();
        new Mod("speed", "Speed", "How fast you are moving.", Cat.INFO, false, true, 0.80f, 0.23f)
                .opt(Opt.choice("unit", "Unit", 0, "Blocks/s", "km/h"))
                .opt(Opt.bool("vertical", "Include up/down", false)).common();

        // ---------------------------------------------------------------- pvp
        new Mod("cps", "CPS Counter", "Left and right click CPS.", Cat.PVP, true, true, 0.01f, 0.45f)
                .opt(Opt.choice("mode", "Show", 0, "Both", "Left", "Right")).common();
        new Mod("combo", "Combo Counter", "Consecutive hits without being hit.", Cat.PVP, true, true, 0.01f, 0.52f)
                .opt(Opt.integer("timeout", "Reset after (sec)", 1, 10, 1, 3)).common();
        new Mod("reach", "Reach Display", "Distance of your last hit.", Cat.PVP, true, true, 0.01f, 0.59f)
                .opt(Opt.integer("decimals", "Decimals", 1, 3, 1, 2)).common();
        new Mod("keystrokes", "Keystrokes", "WASD, Space, Shift and mouse buttons.", Cat.PVP, true, true, 0.86f, 0.60f)
                .opt(Opt.bool("mouse", "Mouse buttons", true))
                .opt(Opt.bool("space", "Space bar", true))
                .opt(Opt.bool("shift", "Shift", true))
                .opt(Opt.color("color", "Text color", 1))
                .opt(Opt.bool("bg", "Background", true))
                .opt(Opt.choice("bgColor", "Background color", 0, Palette.BG_NAMES))
                .opt(Opt.integer("bgAlpha", "Background opacity", 5, 100, 5, 60));

        // ---------------------------------------------------------------- visuals
        new Mod("whoami", "F5 Nametag", "Shows your own IGN, tier tag and totem pops above your head in third-person (F5).", Cat.VISUALS, true, false, 0, 0);
        new Mod("motion_blur", "Motion Blur", "Smooth blur while you move and turn.", Cat.VISUALS, false, false, 0, 0)
                .opt(Opt.integer("strength", "Strength (%)", 5, 95, 5, 50))
                .opt(Opt.integer("fps", "Your usual FPS", 30, 240, 10, 60));

        new Mod("totem_pops", "Totem Pops", "Shows how many totems a player popped, next to their name. Reset with /totemreset.", Cat.PVP, true, false, 0, 0)
                .opt(Opt.bool("nametag", "On nametag", true))
                .opt(Opt.choice("fmt", "Format", 0, "[3]", "3 pops"))
                .opt(Opt.color("color", "Color", 6))
                .opt(Opt.bool("zero", "Show when 0", false))
                .opt(Opt.bool("own", "Count myself", true));

        // ---------------------------------------------------------------- performance
        new Mod("fps_boost", "FPS Boost", "Lowers heavy video settings for more FPS. Never raises your settings; turn it off to get yours back.", Cat.PERF, true, false, 0, 0)
                .opt(Opt.integer("renderDistance", "Max render distance", 2, 32, 1, 10))
                .opt(Opt.integer("simDistance", "Max simulation distance", 5, 32, 1, 8))
                .opt(Opt.integer("entityDistance", "Entity distance (%)", 50, 200, 10, 70))
                .opt(Opt.bool("shadows", "Entity shadows", false))
                .opt(Opt.integer("biomeBlend", "Biome blend", 0, 7, 1, 1))
                .opt(Opt.integer("mipmap", "Mipmap levels", 0, 4, 1, 2))
                .opt(Opt.bool("unlock", "Unlock max FPS", true))
                .opt(Opt.bool("bgLimit", "Slow down when tabbed out", true));
        new Mod("entity_limit", "Entity Limiter", "In crowded chunks (farms, minecarts, armor stands) only the closest entities are drawn.", Cat.PERF, true, false, 0, 0)
                .opt(Opt.integer("cap", "Max per chunk", 1, 50, 1, 10))
                .opt(Opt.integer("near", "Always draw within (blocks)", 0, 16, 1, 6));

        // ---------------------------------------------------------------- tags
        String[] modes = new String[GameMode.values().length + 1];
        modes[0] = "Highest";
        for (int i = 0; i < GameMode.values().length; i++) modes[i + 1] = GameMode.values()[i].display;
        new Mod("cctiers_tag", "CcTiers Tag", "Tier tagger: logo, gamemode icon and tier on nametags, tab list and chat.", Cat.TAGS, true, false, 0, 0)
                .opt(Opt.choice("pos", "Logo & main tag side", 0, "Left", "Right"))
                .opt(Opt.bool("logo", "CcTiers logo", true))
                .opt(Opt.bool("icons", "Gamemode icons", true))
                .opt(Opt.choice("mode", "Gamemode shown", 0, modes))
                .opt(Opt.bool("second", "Second tier", true))
                .opt(Opt.bool("nametag", "Nametag", true))
                .opt(Opt.bool("tab", "Tab list", true))
                .opt(Opt.bool("chat", "Chat", true))
                .opt(Opt.bool("own", "Show on myself", true))
                .opt(Opt.bool("register", "Register me on the API", true));
    }
}
