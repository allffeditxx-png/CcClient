package com.ccclient.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Totem pop counter: how often each player popped a totem since the last /totemreset. */
public final class TotemPops {
    private TotemPops() {}

    private static final String ID = "totem_pops";
    private static final Map<UUID, Integer> pops = new ConcurrentHashMap<>();
    private static final Map<String, UUID> knownNames = new ConcurrentHashMap<>();

    public static void add(UUID id) {
        pops.merge(id, 1, Integer::sum);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) {
            PlayerEntity p = mc.world.getPlayerByUuid(id);
            if (p != null) {
                knownNames.put(p.getName().getString().toLowerCase(Locale.ROOT), id);
            }
        }
    }

    public static int get(UUID id) {
        return pops.getOrDefault(id, 0);
    }

    public static void reset() {
        pops.clear();
        knownNames.clear();
    }

    /** Resets one player by name (checks nearby players, tab list, and previously popped players). */
    public static boolean reset(String name) {
        if (name == null || name.isEmpty()) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        UUID target = null;

        if (mc.world != null) {
            for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
                if (p.getName().getString().equalsIgnoreCase(name)) {
                    target = p.getUuid();
                    break;
                }
            }
        }

        if (target == null && mc.getNetworkHandler() != null) {
            ClientPlayNetworkHandler handler = mc.getNetworkHandler();
            for (PlayerListEntry entry : handler.getPlayerList()) {
                if (entry.getProfile().name().equalsIgnoreCase(name)) {
                    target = entry.getProfile().id();
                    break;
                }
            }
        }

        if (target == null) {
            target = knownNames.get(name.toLowerCase(Locale.ROOT));
        }

        if (target != null) {
            pops.remove(target);
            knownNames.remove(name.toLowerCase(Locale.ROOT));
            return true;
        }
        return false;
    }

    private static Text suffix(int n) {
        String s = Cfg.val(ID, "fmt") == 1 ? " " + n + (n == 1 ? " pop" : " pops") : " [" + n + "]";
        int rgb = Palette.argb(Cfg.val(ID, "color")) & 0xFFFFFF;
        return Text.literal(s).styled(st -> st.withColor(TextColor.fromRgb(rgb)));
    }

    private static Text decorate(UUID id, Text original) {
        int n = get(id);
        if (n == 0 && !Cfg.flag(ID, "zero")) return null;
        return Text.empty().append(original).append(suffix(n));
    }

    public static Text nametag(PlayerEntity player, Text original) {
        if (!Cfg.on(ID) || !Cfg.flag(ID, "nametag") || original == null) return null;
        if (!(player instanceof AbstractClientPlayerEntity)) return null;
        if (player == MinecraftClient.getInstance().player && !Cfg.flag(ID, "own")) return null;
        return decorate(player.getUuid(), original);
    }

    public static Text tab(PlayerListEntry entry, Text original) {
        return null;
    }
}
