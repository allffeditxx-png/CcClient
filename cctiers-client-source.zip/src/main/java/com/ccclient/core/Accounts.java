package com.ccclient.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.mojang.authlib.GameProfile;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * In-game account changer. Saved names are switched as offline (cracked) accounts: the game's session is
 * replaced, so offline-mode servers and singleplayer see the new name. The launcher's own account can always be restored.
 */
public final class Accounts {
    private Accounts() {}

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Pattern VALID = Pattern.compile("^[A-Za-z0-9_]{3,16}$");
    private static List<String> names = null;
    private static Session original = null;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("ccclient_accounts.json");
    }

    /** Remembers the account the launcher started the game with. */
    public static void captureOriginal(MinecraftClient mc) {
        try {
            if (original == null && mc.getSession() != null) original = mc.getSession();
        } catch (Throwable ignored) {
        }
    }

    public static String originalName() {
        return original == null ? "" : original.getUsername();
    }

    public static String currentName() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.getSession() == null ? "" : mc.getSession().getUsername();
    }

    public static synchronized List<String> list() {
        if (names == null) {
            names = new ArrayList<>();
            try {
                if (Files.exists(file())) {
                    List<String> l = GSON.fromJson(Files.readString(file()), new TypeToken<List<String>>() {}.getType());
                    if (l != null) names.addAll(l);
                }
            } catch (Exception ignored) {
            }
        }
        return names;
    }

    private static void save() {
        try {
            Files.writeString(file(), GSON.toJson(list()));
        } catch (Exception ignored) {
        }
    }

    public static boolean valid(String name) {
        return name != null && VALID.matcher(name).matches();
    }

    /** Returns an error text or null. */
    public static synchronized String add(String name) {
        if (!valid(name)) return "Use 3-16 letters, numbers or _";
        for (String n : list()) if (n.equalsIgnoreCase(name)) return "Already saved";
        list().add(name);
        save();
        return null;
    }

    public static synchronized void remove(String name) {
        list().remove(name);
        save();
    }

    /** Switches to a saved offline account. Returns an error text or null. */
    public static String switchTo(MinecraftClient mc, String name) {
        if (!valid(name)) return "Invalid name";
        try {
            captureOriginal(mc);
            return apply(mc, offlineSession(name), name, offlineUuid(name));
        } catch (Throwable t) {
            return "Could not switch (" + t.getClass().getSimpleName() + ")";
        }
    }

    /** Goes back to the account the launcher started with. */
    public static String useOriginal(MinecraftClient mc) {
        if (original == null) return "No launcher account known";
        try {
            UUID id = original.getUuidOrNull();
            return apply(mc, original, original.getUsername(), id);
        } catch (Throwable t) {
            return "Could not switch (" + t.getClass().getSimpleName() + ")";
        }
    }

    private static UUID offlineUuid(String name) {
        return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
    }

    private static Session offlineSession(String name) throws Exception {
        UUID uuid = offlineUuid(name);
        Constructor<?>[] cs = Session.class.getDeclaredConstructors();
        Arrays.sort(cs, (a, b) -> Integer.compare(b.getParameterCount(), a.getParameterCount()));
        Throwable last = null;
        for (Constructor<?> c : cs) {
            try {
                Class<?>[] types = c.getParameterTypes();
                Object[] args = new Object[types.length];
                int strings = 0;
                for (int i = 0; i < types.length; i++) {
                    Class<?> t = types[i];
                    if (t == String.class) args[i] = strings++ == 0 ? name : "0";
                    else if (t == UUID.class) args[i] = uuid;
                    else if (t == Optional.class) args[i] = Optional.empty();
                    else if (t.isEnum()) {
                        Object[] consts = t.getEnumConstants();
                        Object pick = consts[0];
                        for (Object o : consts) if (o.toString().equalsIgnoreCase("LEGACY")) pick = o;
                        args[i] = pick;
                    }
                }
                c.setAccessible(true);
                return (Session) c.newInstance(args);
            } catch (Throwable t) {
                last = t;
            }
        }
        throw new IllegalStateException("no usable Session constructor", last);
    }

    private static String apply(MinecraftClient mc, Session session, String name, UUID uuid) throws Exception {
        boolean done = false;
        for (Field f : MinecraftClient.class.getDeclaredFields()) {
            if (f.getType() == Session.class) {
                f.setAccessible(true);
                f.set(mc, session);
                done = true;
            }
        }
        if (!done) return "This version stores the account differently";
        // keep the cached game profile in step, if the game has one
        for (Field f : MinecraftClient.class.getDeclaredFields()) {
            if (f.getType() == GameProfile.class && uuid != null) {
                try {
                    f.setAccessible(true);
                    f.set(mc, new GameProfile(uuid, name));
                } catch (Throwable ignored) {
                }
            }
        }
        return null;
    }
}
