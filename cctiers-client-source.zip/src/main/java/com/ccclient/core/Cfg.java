package com.ccclient.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** config/ccclient.json - enabled flags, option values and HUD positions. */
public final class Cfg {
    public Map<String, Boolean> enabled = new HashMap<>();
    public Map<String, Integer> values = new HashMap<>();
    public Map<String, Float> px = new HashMap<>();
    public Map<String, Float> py = new HashMap<>();

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Cfg inst = new Cfg();
    private static boolean loaded = false;

    /** Safe to call from anywhere, any number of times (the blur pack needs the config very early). */
    public static synchronized void ensureLoaded() {
        if (!loaded) {
            Mods.init();
            load();
        }
    }

    public static void load() {
        loaded = true;
        try {
            Path f = file();
            if (Files.exists(f)) {
                Cfg c = GSON.fromJson(Files.readString(f), Cfg.class);
                if (c != null) {
                    if (c.enabled == null) c.enabled = new HashMap<>();
                    if (c.values == null) c.values = new HashMap<>();
                    if (c.px == null) c.px = new HashMap<>();
                    if (c.py == null) c.py = new HashMap<>();
                    inst = c;
                }
            }
        } catch (Exception ignored) {
        }
        com.ccclient.ui.Gfx.applyTheme();
        save();
    }

    public static void save() {
        try {
            Files.writeString(file(), GSON.toJson(inst));
        } catch (Exception ignored) {
        }
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("ccclient.json");
    }

    // ------------------------------------------------------------------ helpers

    public static boolean on(String id) {
        Boolean b = inst.enabled.get(id);
        if (b != null) return b;
        Mod m = Mod.get(id);
        return m != null && m.defaultOn;
    }

    public static void setOn(String id, boolean v) {
        inst.enabled.put(id, v);
        save();
    }

    public static int val(String id, String key) {
        Integer v = inst.values.get(id + "." + key);
        if (v != null) return v;
        Mod m = Mod.get(id);
        if (m != null) for (Opt o : m.opts) if (o.key.equals(key)) return o.def;
        return 0;
    }

    public static boolean flag(String id, String key) {
        return val(id, key) != 0;
    }

    public static void setVal(String id, String key, int v) {
        inst.values.put(id + "." + key, v);
    }

    public static float posX(Mod m) {
        Float f = inst.px.get(m.id);
        return f != null ? f : m.dx;
    }

    public static float posY(Mod m) {
        Float f = inst.py.get(m.id);
        return f != null ? f : m.dy;
    }

    public static void setPos(String id, float x, float y) {
        inst.px.put(id, x);
        inst.py.put(id, y);
    }

    public static void resetPos(String id) {
        inst.px.remove(id);
        inst.py.remove(id);
    }

    public static void resetModule(Mod m) {
        inst.enabled.remove(m.id);
        for (Opt o : m.opts) inst.values.remove(m.id + "." + o.key);
        resetPos(m.id);
        save();
    }
}
