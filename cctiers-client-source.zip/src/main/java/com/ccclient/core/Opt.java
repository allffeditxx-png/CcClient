package com.ccclient.core;

/** One editable setting of a module. Every value is stored as an int in the config. */
public final class Opt {
    public enum Type { BOOL, INT, COLOR, CHOICE }

    public final Type type;
    public final String key;
    public final String label;
    public final int min, max, step, def;
    public final String[] choices;

    private Opt(Type type, String key, String label, int min, int max, int step, int def, String[] choices) {
        this.type = type;
        this.key = key;
        this.label = label;
        this.min = min;
        this.max = max;
        this.step = step;
        this.def = def;
        this.choices = choices;
    }

    public static Opt bool(String key, String label, boolean def) {
        return new Opt(Type.BOOL, key, label, 0, 1, 1, def ? 1 : 0, null);
    }

    public static Opt integer(String key, String label, int min, int max, int step, int def) {
        return new Opt(Type.INT, key, label, min, max, step, def, null);
    }

    public static Opt color(String key, String label, int defIndex) {
        return new Opt(Type.COLOR, key, label, 0, Palette.COUNT - 1, 1, defIndex, null);
    }

    public static Opt choice(String key, String label, int def, String... choices) {
        return new Opt(Type.CHOICE, key, label, 0, choices.length - 1, 1, def, choices);
    }
}
