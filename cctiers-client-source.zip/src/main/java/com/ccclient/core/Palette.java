package com.ccclient.core;

public final class Palette {
    private Palette() {}

    public static final String[] NAMES = {"Gold", "White", "Red", "Green", "Cyan", "Pink", "Orange", "Blue", "Chroma"};
    private static final int[] RGB = {0xF5C518, 0xFFFFFF, 0xFF5555, 0x55FF55, 0x55FFFF, 0xFF77CC, 0xFFA040, 0x5599FF, 0xFFFFFF};
    public static final String[] BG_NAMES = {"Black", "Dark gray", "Brown", "Navy", "Gold", "Red", "Green"};
    private static final int[] BG_RGB = {0x000000, 0x262626, 0x2B1D0A, 0x0B1633, 0xF5C518, 0x8A1C1C, 0x14401F};
    public static final int COUNT = NAMES.length;

    public static int bgRgb(int index) {
        if (index < 0 || index >= BG_RGB.length) index = 0;
        return BG_RGB[index];
    }
    public static final int CHROMA = COUNT - 1;

    /** Opaque ARGB colour. phase shifts the rainbow so text letters can differ. */
    public static int argb(int index, int phase) {
        if (index < 0 || index >= COUNT) index = 0;
        if (index == CHROMA) {
            float h = ((System.currentTimeMillis() / 12 + phase * 9) % 360) / 360f;
            return 0xFF000000 | hsv(h);
        }
        return 0xFF000000 | RGB[index];
    }

    public static int argb(int index) {
        return argb(index, 0);
    }

    public static int hsv(float h) {
        float r = Math.abs(h * 6 - 3) - 1;
        float g = 2 - Math.abs(h * 6 - 2);
        float b = 2 - Math.abs(h * 6 - 4);
        int ri = (int) (Math.max(0, Math.min(1, r)) * 255);
        int gi = (int) (Math.max(0, Math.min(1, g)) * 255);
        int bi = (int) (Math.max(0, Math.min(1, b)) * 255);
        return (ri << 16) | (gi << 8) | bi;
    }

    public static int withAlpha(int argb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (argb & 0xFFFFFF);
    }
}
