package com.ccclient.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** One feature card. Definitions live in Mods.java. */
public final class Mod {
    public enum Cat {
        INFO("Info"), PVP("PvP"), VISUALS("Visuals"), TAGS("Tags");

        public final String label;

        Cat(String label) {
            this.label = label;
        }
    }

    public static final List<Mod> ALL = new ArrayList<>();
    private static final Map<String, Mod> BY_ID = new HashMap<>();

    public final String id, name, desc;
    public final Cat cat;
    public final boolean defaultOn;
    /** true = a HUD element the player can drag around. */
    public final boolean positioned;
    public final float dx, dy;
    public final List<Opt> opts = new ArrayList<>();

    Mod(String id, String name, String desc, Cat cat, boolean defaultOn, boolean positioned, float dx, float dy) {
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.cat = cat;
        this.defaultOn = defaultOn;
        this.positioned = positioned;
        this.dx = dx;
        this.dy = dy;
        ALL.add(this);
        BY_ID.put(id, this);
    }

    public static Mod get(String id) {
        return BY_ID.get(id);
    }

    Mod opt(Opt o) {
        opts.add(o);
        return this;
    }

    /** Text colour, background on/off and background opacity - shared by every text panel. */
    Mod common() {
        return opt(Opt.color("color", "Text color", 1))
                .opt(Opt.bool("bg", "Background", true))
                .opt(Opt.choice("bgColor", "Background color", 0, Palette.BG_NAMES))
                .opt(Opt.integer("bgAlpha", "Background opacity", 5, 100, 5, 60));
    }
}
