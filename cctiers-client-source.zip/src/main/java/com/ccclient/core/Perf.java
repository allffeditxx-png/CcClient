package com.ccclient.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.option.SimpleOption;

/**
 * FPS Boost card. Only ever LOWERS heavy video settings (it never raises something you set lower),
 * remembers what you had, and puts it all back when the card is turned off or the game closes.
 */
public final class Perf {
    private Perf() {}

    private static boolean applied = false;
    private static boolean bgLimited = false;
    private static int sig = 0;
    private static int tickCount = 0;

    private static int oView, oSim, oBlend, oMip, oFps;
    private static double oEnt;
    private static boolean oShadow;
    private static ParticlesMode oPart;
    private static GraphicsMode oGfx;

    private static final String ID = "fps_boost";

    private static <T> void set(SimpleOption<T> opt, T v) {
        try {
            if (!opt.getValue().equals(v)) opt.setValue(v);
        } catch (Throwable ignored) {
        }
    }

    public static void tick(MinecraftClient mc) {
        if (mc.options == null) return;
        if (++tickCount % 5 != 0) return;
        try {
            if (Cfg.on(ID)) {
                if (!applied) {
                    save(mc.options);
                    applied = true;
                    sig = -1;
                }
                int s = signature();
                if (s != sig) {
                    apply(mc.options);
                    sig = s;
                }
                background(mc);
            } else if (applied) {
                restore(mc);
            }
        } catch (Throwable ignored) {
        }
    }

    private static int signature() {
        int h = 17;
        for (Opt o : Mod.get(ID).opts) h = h * 31 + Cfg.val(ID, o.key);
        return h;
    }

    private static void save(GameOptions o) {
        oView = o.getViewDistance().getValue();
        oSim = o.getSimulationDistance().getValue();
        oEnt = o.getEntityDistanceScaling().getValue();
        oShadow = o.getEntityShadows().getValue();
        oBlend = o.getBiomeBlendRadius().getValue();
        oMip = o.getMipmapLevels().getValue();
        oFps = o.getMaxFps().getValue();
        oPart = o.getParticles().getValue();
        oGfx = o.getGraphicsMode().getValue();
    }

    private static void apply(GameOptions o) {
        set(o.getViewDistance(), Math.min(oView, Cfg.val(ID, "renderDistance")));
        set(o.getSimulationDistance(), Math.min(oSim, Cfg.val(ID, "simDistance")));
        set(o.getEntityDistanceScaling(), Math.max(0.5, Math.min(oEnt, Cfg.val(ID, "entityDistance") / 100.0)));
        set(o.getEntityShadows(), Cfg.flag(ID, "shadows") ? oShadow : false);
        set(o.getBiomeBlendRadius(), Math.min(oBlend, Cfg.val(ID, "biomeBlend")));
        set(o.getMipmapLevels(), Math.min(oMip, Cfg.val(ID, "mipmap")));

        ParticlesMode[] parts = ParticlesMode.values();
        int pi = Math.max(oPart.ordinal(), Math.min(Cfg.val(ID, "particles"), parts.length - 1));
        set(o.getParticles(), parts[pi]);

        if (Cfg.val(ID, "graphics") == 0 && oGfx.ordinal() > GraphicsMode.FAST.ordinal()) {
            set(o.getGraphicsMode(), GraphicsMode.FAST);
        } else {
            set(o.getGraphicsMode(), oGfx);
        }
        if (!bgLimited) set(o.getMaxFps(), Cfg.flag(ID, "unlock") ? 260 : oFps);
    }

    /** Saves a lot of power when the game window is not in front. */
    private static void background(MinecraftClient mc) {
        if (!Cfg.flag(ID, "bgLimit")) {
            if (bgLimited) {
                bgLimited = false;
                set(mc.options.getMaxFps(), Cfg.flag(ID, "unlock") ? 260 : oFps);
            }
            return;
        }
        boolean focused = mc.isWindowFocused();
        if (!focused && !bgLimited) {
            bgLimited = true;
            set(mc.options.getMaxFps(), 20);
        } else if (focused && bgLimited) {
            bgLimited = false;
            set(mc.options.getMaxFps(), Cfg.flag(ID, "unlock") ? 260 : oFps);
        }
    }

    public static void restore(MinecraftClient mc) {
        if (!applied || mc.options == null) return;
        try {
            GameOptions o = mc.options;
            set(o.getViewDistance(), oView);
            set(o.getSimulationDistance(), oSim);
            set(o.getEntityDistanceScaling(), oEnt);
            set(o.getEntityShadows(), oShadow);
            set(o.getBiomeBlendRadius(), oBlend);
            set(o.getMipmapLevels(), oMip);
            set(o.getMaxFps(), oFps);
            set(o.getParticles(), oPart);
            set(o.getGraphicsMode(), oGfx);
        } catch (Throwable ignored) {
        }
        applied = false;
        bgLimited = false;
    }
}
